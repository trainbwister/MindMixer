namespace NBack
{
	partial class Viewport
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if( disposing && ( components != null ) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.pnView = new System.Windows.Forms.Panel();
      this.SuspendLayout();
      // 
      // pnView
      // 
      this.pnView.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pnView.Location = new System.Drawing.Point( 0, 0 );
      this.pnView.Name = "pnView";
      this.pnView.Size = new System.Drawing.Size( 829, 723 );
      this.pnView.TabIndex = 0;
      // 
      // Viewport
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF( 6F, 13F );
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size( 829, 723 );
      this.Controls.Add( this.pnView );
      this.Name = "Viewport";
      this.Text = "Brain Rage";
      this.ResumeLayout( false );

		}

		#endregion

		private System.Windows.Forms.Panel pnView;
	}
}

