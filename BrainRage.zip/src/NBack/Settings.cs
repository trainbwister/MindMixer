/*
 
Please feel free to contact me with any questions or bugs.
  E-Mail:         shawnpresser@gmail.com
  AOL Messenger:  NoGlasses4Me
 
License:
  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, as long as this permission notice shall be included 
  in all copies or substantial portions of the Software.

Enjoy!

- Shawn Presser

 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace NBack
{
  public partial class Settings : Form
  {
    public Settings()
    {
      InitializeComponent();
      this.StartPosition = FormStartPosition.CenterScreen;
      _prevNBack = 2;
      nBack.Select( nBack.Text.Length, 0 );
    }

    int _prevNBack;

    public bool MarathonMode
    {
      get { return cbMarathonMode.Checked; }
    }

    public bool FlashOnMiss
    {
      get { return cbFlashRedOnMiss.Checked; }
    }

    public bool AudioTraining
    {
      get { return cbAudioTraining.Checked; }
    }

    public bool VisualTraining
    {
      get { return cbVisualTraining.Checked; }
    }

    public bool KeepScore
    {
      get { return cbKeepScore.Checked; }
    }

    public int InitialN
    {
      get { return ( int )nBack.Value; }
    }

    public int DurationTrialActive
    {
      get { return ( int )( txtDurationTrialActive.Value * 1000 ); }
    }

    public int DurationTrialHidden
    {
      get { return ( int )( txtDurationTrialHidden.Value * 1000 ); }
    }

    protected override void OnPaintBackground( PaintEventArgs e )
    {
      base.OnPaintBackground( e );

      // fill a gradient.
      using( Brush brush = new LinearGradientBrush( new Rectangle( Point.Empty, this.Size ),
        Color.FromArgb( 70, 83, 90 ), Color.FromArgb( 115, 120, 132 ),
        LinearGradientMode.BackwardDiagonal ) )
      {
        e.Graphics.FillRectangle( brush, this.ClientRectangle );
      }
    }

    private void nBack_ValueChanged( object sender, EventArgs e )
    {
      txtVisualTraining.Text = txtVisualTraining.Text.Replace( _prevNBack.ToString(), nBack.Value.ToString() );
      txtAudioTraining.Text  = txtAudioTraining.Text.Replace( _prevNBack.ToString(), nBack.Value.ToString() );
      _prevNBack = ( int )nBack.Value;
    }

    private void btnDoIt_Click( object sender, EventArgs e )
    {
      this.DialogResult = DialogResult.OK;
      this.Hide();
    }

    private void Settings_PreviewKeyDown( object sender, PreviewKeyDownEventArgs e )
    {
      if( e.KeyCode == Keys.Escape )
        e.IsInputKey = true;
    }

    private void btnReadMore_Click( object sender, EventArgs e )
    {
      System.Diagnostics.Process.Start( "http://shawnpresser.blogspot.com/2008/04/brain-rage.html" );
    }

    private void lblDonate_LinkClicked( object sender, LinkLabelLinkClickedEventArgs e )
    {
      System.Diagnostics.Process.Start( "http://shawnpresser.blogspot.com/2008/04/brain-rage.html" );
    }
  }
}