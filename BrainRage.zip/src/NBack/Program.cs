/*
 
Please feel free to contact me with any questions or bugs.
  E-Mail:         shawnpresser@gmail.com
  AOL Messenger:  NoGlasses4Me
 
License:
  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, as long as this permission notice shall be included 
  in all copies or substantial portions of the Software.

Enjoy!

- Shawn Presser

 */

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using SlimDX;
using SlimDX.Direct3D9;
using System.Runtime.InteropServices;
using System.Drawing;

namespace NBack
{
  // vertex structure for the squares.
	[StructLayout( LayoutKind.Sequential )]
	struct Vertex
	{
		public Vector4 PositionRhw;
		public int Color;

		public static int SizeBytes
		{
			get { return Marshal.SizeOf( typeof( Vertex ) ); }
		}

		public static VertexFormat Format
		{
			get { return VertexFormat.PositionRhw | VertexFormat.Diffuse; }
		}
	}

  // main program.
	static class Program
	{
    // constants.
    static readonly int kTrialsPerBlock     = 20;   // >= 4.
    static readonly int kFlashErrorFor      = 500;  // milliseconds.
    static readonly int kFlashDifficultyFor = 1000; // milliseconds.
    static readonly int kInitialDarkness    = 1000; // milliseconds.

    // mutable constants.
    static int kFlashSquareFor = 500;   // milliseconds.
    static int kHideSquaresFor = 2500;  // milliseconds.

    // interpolate between two colors.
    static int InterpolateColorComponent( int x, int y, float alpha ) { return Math.Max( 0, Math.Min( 255, (int)( (y-x)*alpha+x ) ) ); }
    static System.Drawing.Color InterpolateColors( System.Drawing.Color x, System.Drawing.Color y, float alpha )
    {
      return System.Drawing.Color.FromArgb(
        InterpolateColorComponent( x.A, y.A, alpha ),
        InterpolateColorComponent( x.R, y.R, alpha ),
        InterpolateColorComponent( x.G, y.G, alpha ),
        InterpolateColorComponent( x.B, y.B, alpha ) );
    }

    // FMOD error check.
    static private void ERRCHECK(FMOD.RESULT result)
    {
        if (result != FMOD.RESULT.OK)
        {
            MessageBox.Show("FMOD error! " + result + " - " + FMOD.Error.String(result));
            Environment.Exit(-1);
        }
    }

		private static Vertex[] Rect2Vertices( RectangleF dimensions )
		{
			Vertex[] vertexData = new Vertex[6];

			vertexData[0].PositionRhw = new Vector4( dimensions.Left, dimensions.Top, 0.5f, 1.0f );
			vertexData[0].Color = Color.Red.ToArgb();

			vertexData[1].PositionRhw = new Vector4( dimensions.Right, dimensions.Top, 0.5f, 1.0f );
			vertexData[1].Color = Color.Blue.ToArgb();

			vertexData[2].PositionRhw = new Vector4( dimensions.Right, dimensions.Bottom, 0.5f, 1.0f );
			vertexData[2].Color = Color.Green.ToArgb();

			vertexData[3].PositionRhw = new Vector4( dimensions.Right, dimensions.Bottom, 0.5f, 1.0f );
			vertexData[3].Color = Color.Green.ToArgb();

			vertexData[4].PositionRhw = new Vector4( dimensions.Left, dimensions.Bottom, 0.5f, 1.0f );
			vertexData[4].Color = Color.Gray.ToArgb();

			vertexData[5].PositionRhw = new Vector4( dimensions.Left, dimensions.Top, 0.5f, 1.0f );
			vertexData[5].Color = Color.Red.ToArgb();

			return vertexData;
		}

		private static VertexBuffer BuildVB( Device device, Vertex[] vertexData )
		{
			VertexBuffer vb = new VertexBuffer( device, vertexData.Length * Vertex.SizeBytes, Usage.WriteOnly, VertexFormat.None, Pool.Managed );
			DataStream stream = vb.Lock( 0, 0, LockFlags.None );
			stream.WriteRange( vertexData );
			vb.Unlock();
			return vb;
		}

    class Trial
    {
      public Trial( Random random, int numConsonants, bool visualMatch, bool audioMatch )
      {
        // initialize.
        _NthBack = null;
        _playAudio = true;
        _visualMatch = visualMatch;
        _audioMatch = audioMatch;
        _visualIdx = random.Next( 8 );
        _audioIdx = random.Next( numConsonants );
        _timeRemaining = kFlashSquareFor + kHideSquaresFor;
        FailedVisualMatch = false;
        FailedAudioMatch = false;
      }

      // ----------------------
      Trial _NthBack;
      public Trial NthBack
      {
        get { return _NthBack; }
      }

      public void SetNthBack( Trial nthBack, Random random, int numConsonants )
      {
        _NthBack = nthBack;

        // if we're not a visual match, ensure that our VisualIndex is not equal to NthBack's.
        if( !VisualMatch )
        {
          while( _visualIdx == NthBack.VisualIndex )
            _visualIdx = random.Next( 8 );
        }

        // if we're not an audio match, ensure that our AudioIndex is not equal to NthBack's.
        if( !AudioMatch )
        {
          while( _audioIdx == NthBack.AudioIndex )
            _audioIdx = random.Next( numConsonants );
        }
      }

      // ----------------------
      public bool VisualMatch
      {
        get { return (NthBack != null) && _visualMatch; }
      }

      // ----------------------
      public bool AudioMatch
      {
        get { return (NthBack != null) && _audioMatch; }
      }

      // ----------------------
      public bool FailedVisualMatch;
      public bool FailedAudioMatch;

      // ----------------------
      public int VisualIndex
      {
        get 
        {
          if( VisualMatch )
            return NthBack.VisualIndex;
          else
            return _visualIdx;
        }
      }

      // ----------------------
      public int AudioIndex
      {
        get 
        {
          if( AudioMatch )
            return NthBack.AudioIndex;
          else
            return _audioIdx;
        }
      }

      // ----------------------
      public int TimeRemaining
      {
        get { return _timeRemaining; }
      }

      // ----------------------
      public bool VisualCue
      {
        get { return _timeRemaining > kHideSquaresFor; }
      }

      // ----------------------
      public bool AudioCue
      {
        get 
        {
          // return true exactly once.
          if( _playAudio )
          {
            _playAudio = false;
            return true;
          }
          else
            return false;
        }
      }

      // ----------------------
      bool InProgress
      {
        get { return _timeRemaining > 0; }
      }

      // ----------------------
      public bool Update( int deltaTime )
      {
        // subtract time from the trial clock.
        _timeRemaining -= deltaTime;

        // return whether this trial is still in progress.
        return InProgress;
      }

      bool    _playAudio;
      bool    _visualMatch;
      bool    _audioMatch;
      int     _visualIdx;
      int     _audioIdx;
      int     _timeRemaining;
    }

    // ----------------------
    // A fancy Fischer-Yates-Knuth shuffle.  (It's un-baised.)
    public static void Shuffle<T>( T[] array )
    {
      Random rng = new Random();   // i.e., java.util.Random.
      int n = array.Length;        // The number of items left to shuffle (loop invariant).
      while( n > 1 )
      {
        int k = rng.Next( n );  // 0 <= k < n.
        --n;                       // n is now the last pertinent index;
        T temp = array[ n ];     // swap array[n] with array[k].
        array[ n ] = array[ k ];
        array[ k ] = temp;
      }
    }


    // ----------------------
    class Block
    {
      // ----------------------
      public Block( Random random, int numConsonants, Block prevBlock, int N, bool audio, bool visual )
      {
        // initialize.
        _numVisualErrors        = 0;
        _numAudioErrors         = 0;
        _userPressedVisualKey   = false;
        _userPressedAudioKey    = false;
        _userError              = false;
        _audioTraining          = audio;
        _visualTraining         = visual;

        // generate kTrialsPerBlock+N trials.
        _trials = new Trial[ kTrialsPerBlock+N ];

        for( int i = 0; i < _trials.Length; ++i )
        {
          // generate four N-backs per block that are either audio OR visual matches, but not both.
          if( i < 4 )
          {
            bool isVisualMatch = ( random.NextDouble() < 0.5f );
            _trials[ i ] = new Trial( random, numConsonants, isVisualMatch, !isVisualMatch );
          }
          else if( i < 6 )
          {
            // generate two N-backs per block that are audio AND visual matches simultaneously.
            _trials[ i ] = new Trial( random, numConsonants, true, true );
          }
          else
          {
            // generate kTrialsPerBlock+N-6 trials that are neither audio nor visual matches.
            _trials[ i ] = new Trial( random, numConsonants, false, false );
          }
        }

        // shuffle the trials.
        Shuffle<Trial>( _trials );

        // Set the Nth-back trials.
        for( int i = 0; i < _trials.Length; ++i )
        {
          if( i >= N )
            _trials[ i ].SetNthBack( _trials[ i-N ], random, numConsonants );
          else if( prevBlock != null )
            _trials[ i ].SetNthBack( prevBlock._trials[ prevBlock._trials.Length + i-N ], random, numConsonants );
        }
      }

      // ----------------------
      public Trial[] Trials
      {
        get { return _trials; }
      }

      // ----------------------
      public Trial CurrentTrial
      {
        get { return _trials[ _curTrialIdx ]; }
      }

      // ----------------------
      public bool InProgress
      {
        get { return _curTrialIdx < _trials.Length; }
      }

      // ----------------------
      public int VisualErrors
      {
        get { return _numVisualErrors; }
      }

      // ----------------------
      public int AudioErrors
      {
        get { return _numAudioErrors; }
      }

      // ----------------------
      public bool TrialJustFinished
      {
        get 
        { 
          // report a user error only once.
          if( _trialJustFinished )
          {
            _trialJustFinished = false;
            return true;
          }
          else
            return false;
        }
      }

      // ----------------------
      public bool UserError
      {
        get 
        { 
          // report a user error only once.
          if( _userError )
          {
            _userError = false;
            return true;
          }
          else
            return false;
        }
      }

      // ----------------------
      public int ComputeNextN( int currentN )
      {
        /* From the paper:  "After each block, the
            participants� individual performance was analyzed, and in the following
            block, the level of n was adapted accordingly: If the participant made fewer
            than three mistakes per modality, the level of n increased by 1. It was
            decreased by 1 if more than five mistakes were made, and in all other cases,
            n remained unchanged."
         */
        if( (_numVisualErrors + _numAudioErrors) > 5 )
          return Math.Max( 2, currentN-1 );
        if( _numVisualErrors < 3 && _numAudioErrors < 3 )
          return Math.Min( 19, currentN+1 );
        return currentN;
      }

      // ----------------------
      public bool Update( int deltaTime )
      {
        // if the user pressed the visual key, record that.
        if( Win32.Keyboard.KeyDown( Keys.F ) )
          _userPressedVisualKey = true;

        // if the user pressed the audio key, record that.
        if( Win32.Keyboard.KeyDown( Keys.J ) )
          _userPressedAudioKey = true;

        // update the current trial.
        if( !CurrentTrial.Update( deltaTime ) )
        {
          // the current trial is finished, so grade the user.
          _trialJustFinished = true;

          // was the current trial a visual match?
          if( _visualTraining && CurrentTrial.VisualMatch != _userPressedVisualKey )
          {
            ++_numVisualErrors;
            CurrentTrial.FailedVisualMatch = true;
            _userError = true;
          }
          _userPressedVisualKey = false;

          // was the current trial an audio match?
          if( _audioTraining && CurrentTrial.AudioMatch != _userPressedAudioKey )
          {
            ++_numAudioErrors;
            CurrentTrial.FailedAudioMatch = true;
            _userError = true;
          }
          _userPressedAudioKey = false;

          // advance to the next trial.
          if( !Advance() )
          {
            // if all trials are complete, return false.
            return false;
          }
        }

        // return true to indicate that this block is still processing trials.
        return true;
      }

      // ----------------------
      bool Advance()
      {
        // at this point, CurrentTrial.TimeRemaining is negative.  To make sure
        // we don't lose track of any time, we must subtract that time from the 
        // next trial.

        // advance to the next trial.
        _curTrialIdx++;

        // if we've advanced through all trials, return false.
        if( _curTrialIdx == _trials.Length )
          return false;

        // don't waste any time.
        _trials[ _curTrialIdx ].Update( _trials[ _curTrialIdx-1 ].TimeRemaining );

        // return true to indicate success.
        return true;
      }

      // ----------------------
      Trial[]   _trials;
      int       _curTrialIdx;
      bool      _userPressedVisualKey;
      bool      _userPressedAudioKey;
      bool      _userError;
      bool      _trialJustFinished;
      int       _numVisualErrors;
      int       _numAudioErrors;
      bool      _audioTraining;
      bool      _visualTraining;
    }

    // ----------------------
    public static string Pluralize( string singular, string plural, string none, int number )
    {
      if( number == 0 )
        return none + " " + plural;
      if( Math.Abs( number ) == 1 )
        return number.ToString() + " " + singular;
      return number.ToString() + " " + plural;
    }

		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault( false );

			// initialize the program.
			_done = false;

			// initialize the viewport.
			Viewport viewport = new Viewport();
			Control view = viewport.View;
			viewport.FormClosing += new FormClosingEventHandler( viewport_FormClosing );

      Settings settings = new Settings();
      if( settings.ShowDialog() == DialogResult.Cancel )
        return;

      kFlashSquareFor = settings.DurationTrialActive;
      kHideSquaresFor = settings.DurationTrialHidden;

			viewport.Show();
      viewport.BringToFront();

			// initialize Direct3D.
			Direct3D.Initialize();

			PresentParameters presentParams = new PresentParameters();
			presentParams.BackBufferWidth = view.Width;
			presentParams.BackBufferHeight = view.Height;
			presentParams.DeviceWindowHandle = view.Handle;

			Device device = null;
			if( Direct3D.AdapterCount > 1 )
			{
				// Enable support for NVPerfHUD, if we're using it. 
				for( int i = 0; i < Direct3D.AdapterCount; i++ )
				{
					AdapterDetails details = Direct3D.GetAdapterIdentifier( i );
					if( details.Description.ToLower().Contains( "perfhud" ) )
					{
						device = new Device( i, DeviceType.Reference, view.Handle, CreateFlags.HardwareVertexProcessing, presentParams );
						break;
					}
				}
			}
			if( device == null )
			{
				// No NVPerfHUD, just standard initialization.
				device = new Device( 0, DeviceType.Hardware, view.Handle, CreateFlags.HardwareVertexProcessing, presentParams );
			}

      // initialize FMOD.
      FMOD.System system = null;
      uint version = 0;
      FMOD.RESULT fmodResult;
      fmodResult = FMOD.Factory.System_Create( ref system );
      ERRCHECK( fmodResult );

      fmodResult = system.getVersion( ref version );
      ERRCHECK( fmodResult );
      if( version < FMOD.VERSION.number )
      {
        MessageBox.Show( "Error!  You are using an old version of FMOD " + version.ToString( "X" ) + ".  This program requires " + FMOD.VERSION.number.ToString( "X" ) + "." );
        Application.Exit();
        return;
      }

      fmodResult = system.init( 32, FMOD.INITFLAG.NORMAL, ( IntPtr )null );
      ERRCHECK( fmodResult );

      // load 8 consonants.
      // possible consonants are:  new char[] { 'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Z' };
      char[] consonantLetters = new char[] { 'B', 'F', 'J', 'K', 'Q', 'R', 'W', 'X' };
      FMOD.Sound[] consonants = new FMOD.Sound[ consonantLetters.Length ];
      for( int i = 0; i < consonants.Length; ++i )
      {
        string consonantFile = "sounds/" + consonantLetters[ i ].ToString() + ".mp3";

        FMOD.RESULT loadingResult = system.createSound( consonantFile, FMOD.MODE.HARDWARE, ref consonants[i] );
        if( FMOD.RESULT.OK != loadingResult )
        {
          MessageBox.Show( "Failed to load " + consonantFile + ": " + FMOD.Error.String( loadingResult ) );
          Application.Exit();
          return;
        }
      }

			// create the grid of squares.
			VertexBuffer[] squares = new VertexBuffer[ 8 ];
			bool[] drawSquare = new bool[ 8 ];
			for( int i = 0; i < 8; ++i )
				drawSquare[ i ] = false;

			SizeF rectSize = new SizeF( 100, 100 );
      SizeF padding = new SizeF( 150, 100 );

			// top row.
      squares[ 0 ] = BuildVB( device, Rect2Vertices( new RectangleF( view.Left                             + padding.Width,     padding.Height, rectSize.Width, rectSize.Height ) ) );
      squares[ 1 ] = BuildVB( device, Rect2Vertices( new RectangleF( view.Width/2.0f - rectSize.Width/2.0f,                     padding.Height, rectSize.Width, rectSize.Height ) ) );
      squares[ 2 ] = BuildVB( device, Rect2Vertices( new RectangleF( view.Right - rectSize.Width           - padding.Width,     padding.Height, rectSize.Width, rectSize.Height ) ) );

      // middle row.
      squares[ 3 ] = BuildVB( device, Rect2Vertices( new RectangleF( view.Left                             + padding.Width,     view.Height/2.0f - rectSize.Height/2.0f, rectSize.Width, rectSize.Height ) ) );
      squares[ 4 ] = BuildVB( device, Rect2Vertices( new RectangleF( view.Right - rectSize.Width           - padding.Width,     view.Height/2.0f - rectSize.Height/2.0f, rectSize.Width, rectSize.Height ) ) );

      // bottom row.
      squares[ 5 ] = BuildVB( device, Rect2Vertices( new RectangleF( view.Left                             + padding.Width,     view.Height - rectSize.Height - padding.Height, rectSize.Width, rectSize.Height ) ) );
      squares[ 6 ] = BuildVB( device, Rect2Vertices( new RectangleF( view.Width/2.0f - rectSize.Width/2.0f,                     view.Height - rectSize.Height - padding.Height, rectSize.Width, rectSize.Height ) ) );
      squares[ 7 ] = BuildVB( device, Rect2Vertices( new RectangleF( view.Right - rectSize.Width           - padding.Width,     view.Height - rectSize.Height - padding.Height, rectSize.Width, rectSize.Height ) ) );

      // initialize game.
      Random random = new Random( DateTime.Now.Millisecond );
      int N = settings.InitialN;
      Block curBlock = new Block( random, consonants.Length, null, N, settings.AudioTraining, settings.VisualTraining );
      int windupTime = kInitialDarkness;
      int totalNumBlocks = 0;
      int totalNumVisualErrors = 0;
      int totalNumAudioErrors = 0;
      int totalNumTrials = 0;
      int flashErrorClock = 0;
      int flashDifficultyClock = 0;
      bool displayedHelp = false;
      SlimDX.Direct3D9.Font Font_NBack = new SlimDX.Direct3D9.Font( device, new System.Drawing.Font( FontFamily.GenericSansSerif, 20.0f ) );
      SlimDX.Direct3D9.Font Font_Interim = new SlimDX.Direct3D9.Font( device, new System.Drawing.Font( FontFamily.GenericSansSerif, 16.0f ) );
      SlimDX.Direct3D9.Font Font_Scores = new SlimDX.Direct3D9.Font( device, new System.Drawing.Font( FontFamily.GenericSansSerif, 14.0f ) );

      // initialize time.
      DateTime prevTime = DateTime.Now;
      DateTime curTime = DateTime.Now;

			// update the program.
			while( !_done )
			{
        // compute delta time.
        curTime = DateTime.Now;
        int dt = (curTime - prevTime).Milliseconds;
        prevTime = curTime;

        // update timers.
        windupTime -= dt;
        
        flashErrorClock -= dt;
        if( flashErrorClock < 0 )
          flashErrorClock = 0;

        flashDifficultyClock -= dt;
        if( flashDifficultyClock < 0 )
          flashDifficultyClock = 0;

        // update squares.
        for( int i = 0; i < 8; ++i )
          drawSquare[ i ] = false;

        if( windupTime < 0 )
        {
          // update the current block.
          bool blockInProgress = curBlock.Update( dt );

          // update stats.
          if( curBlock.TrialJustFinished)
            ++totalNumTrials;

          if( settings.FlashOnMiss && curBlock.UserError )
          {
            flashErrorClock = kFlashErrorFor;
          }

          // if the current block is finished, update N and start a new one.
          if( !blockInProgress )
          {
            // present the scorecard and offer a break, unless the user is playing in marathon mode.
            if( !settings.MarathonMode )
            {
              while( true )
              {
                // continue when the user presses space.
                if( Form.ActiveForm == viewport && Win32.Keyboard.KeyDown( Keys.Space ) )
                {
                  // update the current time.
                  windupTime = kInitialDarkness;
                  curTime = DateTime.Now;
                  prevTime = curTime;
                  flashErrorClock = 0;
                  break;
                }

                // report the scorecard to the user.
                device.Clear( ClearFlags.Target | ClearFlags.ZBuffer, new Color4( System.Drawing.Color.Black ), 1.0f, 0 );
                device.BeginScene();

                Font_NBack.DrawString( null, 
                  "Block " + (totalNumBlocks+1).ToString() + " Clear",
                  new Rectangle( 0, 200, view.Width, view.Height-200 ),
                  DrawTextFormat.Center | DrawTextFormat.Top, 
                  new Color4( System.Drawing.Color.LightGray ) );

                if( !displayedHelp && curBlock.ComputeNextN( N ) == 3 )
                {
                  Font_Interim.DrawString( null, 
                    Pluralize( "visual error", "visual errors", "No", curBlock.VisualErrors ) + " and " 
                    + Pluralize( "audio error", "audio errors", "no", curBlock.AudioErrors ) + ".  \nYour next difficulty level is " + curBlock.ComputeNextN( N ) + ",\n"
                    + "which means you must identify squares\nand letters that are " + curBlock.ComputeNextN( N ) + " positions back, not " + N + ".\n"
                    + "Press space when you're ready.",
                    view.ClientRectangle, 
                    DrawTextFormat.Center | DrawTextFormat.VCenter, 
                    new Color4( System.Drawing.Color.LightGray ) );
                }
                else
                {
                  Font_Interim.DrawString( null, 
                    Pluralize( "visual error", "visual errors", "No", curBlock.VisualErrors ) + " and " 
                    + Pluralize( "audio error", "audio errors", "no", curBlock.AudioErrors ) + ".  \nYour next difficulty level is " + curBlock.ComputeNextN( N ) + ".\n"
                    + "Press space when you're ready.",
                    view.ClientRectangle, 
                    DrawTextFormat.Center | DrawTextFormat.VCenter, 
                    new Color4( System.Drawing.Color.LightGray ) );
                }

                device.EndScene();
                device.Present();

                // pump the application events.
                Application.DoEvents();
                System.Threading.Thread.Sleep(1); // yield CPU time.

                // exit if the user has exited.
                if( _done )
                  return;
              }
            }

            // help is no longer required.
            displayedHelp = true;

            // update N-value.
            int nextN = curBlock.ComputeNextN( N );
            if( N != nextN )
            {
              flashDifficultyClock = kFlashDifficultyFor;
            }
            N = nextN;

            // update stats.
            totalNumVisualErrors += curBlock.VisualErrors;
            totalNumAudioErrors += curBlock.AudioErrors;
            ++totalNumBlocks;

            // create the next block.
            curBlock = new Block( random, consonants.Length, settings.MarathonMode ? curBlock : null, N, settings.AudioTraining, settings.VisualTraining );
            continue;
          }

          // output the current trial's visual cue.
          if( settings.VisualTraining && curBlock.CurrentTrial.VisualCue )
          {
            drawSquare[ curBlock.CurrentTrial.VisualIndex ] = true;
            //if( curBlock.CurrentTrial.NthBack != null )
              //drawSquare[ curBlock.CurrentTrial.NthBack.VisualIndex ] = true;
          }

          // output the current trial's audio cue.
          if( settings.AudioTraining && curBlock.CurrentTrial.AudioCue )
          {
            FMOD.Channel channel = null;
            FMOD.RESULT playing = system.playSound( FMOD.CHANNELINDEX.FREE, consonants[ curBlock.CurrentTrial.AudioIndex ], false, ref channel );
            if( playing != FMOD.RESULT.OK )
            {
              MessageBox.Show( "Failed to play sound for the letter " + consonantLetters[ curBlock.CurrentTrial.AudioIndex ] + ": " + FMOD.Error.String( playing ) );
              Application.Exit();
              return;
            }
            channel.setVolume( 0.5f );
          }
        }

        // update FMOD.
        system.update();

				// clear the frame buffer.
				device.Clear( ClearFlags.Target | ClearFlags.ZBuffer, 
          InterpolateColors( System.Drawing.Color.Black, System.Drawing.Color.DarkRed, flashErrorClock / (float)kFlashErrorFor ),
          1.0f, 
          0 );
				device.BeginScene();

        // paint the squares.
				for( int i = 0; i < 8; ++i )
				{
					if( drawSquare[ i ] )
					{
						device.SetStreamSource( 0, squares[ i ], 0, Vertex.SizeBytes );
						device.VertexFormat = Vertex.Format;
						device.DrawPrimitives( PrimitiveType.TriangleList, 0, 2 );
					}
				}

        int kTextPadding = 12;

        // paint the current N.
        Font_NBack.DrawString( null, 
          N.ToString() + " Back", new Rectangle( 0, kTextPadding, view.Width, view.Height-kTextPadding ), 
          DrawTextFormat.Top | DrawTextFormat.Center, 
          new Color4( InterpolateColors( System.Drawing.Color.LightGray, System.Drawing.Color.DarkBlue, flashDifficultyClock / (float)kFlashDifficultyFor ) ) );

        if( settings.KeepScore )
        {
          // paint the score.
          Font_Scores.DrawString( null, 
            Pluralize( "visual error", "visual errors", "No", totalNumVisualErrors + curBlock.VisualErrors ) + ".\n" 
            + Pluralize( "audio error", "audio errors", "No", totalNumAudioErrors + curBlock.AudioErrors ) + ".",
            new Rectangle( 0, kTextPadding, view.Width-kTextPadding, view.Height-kTextPadding ), 
            DrawTextFormat.Top | DrawTextFormat.Right, 
            new Color4( System.Drawing.Color.LightSteelBlue ) );
        }

        // present the frame buffer to the screen.
				device.EndScene();
				device.Present();

				// process any Windows events.
				Application.DoEvents();
        System.Threading.Thread.Sleep( 1 ); // yield CPU time.

			}
		}

		static void viewport_FormClosing( object sender, FormClosingEventArgs e )
		{
			_done = true;
		}

		static bool _done;
	}
}