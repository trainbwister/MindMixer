/*
 
Please feel free to contact me with any questions or bugs.
  E-Mail:         shawnpresser@gmail.com
  AOL Messenger:  NoGlasses4Me

License:
  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, as long as this permission notice shall be included 
  in all copies or substantial portions of the Software.

Enjoy!

- Shawn Presser

 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NBack
{
	public partial class Viewport : Form
	{
		public Viewport()
		{
			InitializeComponent();
      this.StartPosition = FormStartPosition.CenterScreen;
		}

		public Control View
		{
			get
			{
				return pnView;
			}
		}
	}
}