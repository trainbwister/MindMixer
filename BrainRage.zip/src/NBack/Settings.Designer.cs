namespace NBack
{
  partial class Settings
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose( bool disposing )
    {
      if( disposing && ( components != null ) )
      {
        components.Dispose();
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.cbMarathonMode = new System.Windows.Forms.CheckBox();
      this.cbFlashRedOnMiss = new System.Windows.Forms.CheckBox();
      this.cbVisualTraining = new System.Windows.Forms.CheckBox();
      this.cbAudioTraining = new System.Windows.Forms.CheckBox();
      this.label1 = new System.Windows.Forms.Label();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.txtAudioTraining = new System.Windows.Forms.Label();
      this.txtVisualTraining = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.label15 = new System.Windows.Forms.Label();
      this.label10 = new System.Windows.Forms.Label();
      this.label9 = new System.Windows.Forms.Label();
      this.cbKeepScore = new System.Windows.Forms.CheckBox();
      this.nBack = new System.Windows.Forms.NumericUpDown();
      this.label11 = new System.Windows.Forms.Label();
      this.btnDoIt = new System.Windows.Forms.Button();
      this.button1 = new System.Windows.Forms.Button();
      this.label2 = new System.Windows.Forms.Label();
      this.txtDurationTrialActive = new System.Windows.Forms.NumericUpDown();
      this.txtDurationTrialHidden = new System.Windows.Forms.NumericUpDown();
      this.label8 = new System.Windows.Forms.Label();
      this.label12 = new System.Windows.Forms.Label();
      this.label13 = new System.Windows.Forms.Label();
      this.label14 = new System.Windows.Forms.Label();
      this.label16 = new System.Windows.Forms.Label();
      this.btnReadMore = new System.Windows.Forms.Button();
      this.label17 = new System.Windows.Forms.Label();
      this.lblDonate = new System.Windows.Forms.LinkLabel();
      this.label18 = new System.Windows.Forms.Label();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      ( ( System.ComponentModel.ISupportInitialize )( this.nBack ) ).BeginInit();
      ( ( System.ComponentModel.ISupportInitialize )( this.txtDurationTrialActive ) ).BeginInit();
      ( ( System.ComponentModel.ISupportInitialize )( this.txtDurationTrialHidden ) ).BeginInit();
      this.SuspendLayout();
      // 
      // cbMarathonMode
      // 
      this.cbMarathonMode.AutoSize = true;
      this.cbMarathonMode.Font = new System.Drawing.Font( "Lucida Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.cbMarathonMode.ForeColor = System.Drawing.Color.FromArgb( ( ( int )( ( ( byte )( 211 ) ) ) ), ( ( int )( ( ( byte )( 177 ) ) ) ), ( ( int )( ( ( byte )( 179 ) ) ) ) );
      this.cbMarathonMode.Location = new System.Drawing.Point( 25, 18 );
      this.cbMarathonMode.Name = "cbMarathonMode";
      this.cbMarathonMode.Size = new System.Drawing.Size( 134, 19 );
      this.cbMarathonMode.TabIndex = 7;
      this.cbMarathonMode.Text = "Marathon Mode";
      this.cbMarathonMode.UseVisualStyleBackColor = true;
      // 
      // cbFlashRedOnMiss
      // 
      this.cbFlashRedOnMiss.AutoSize = true;
      this.cbFlashRedOnMiss.Checked = true;
      this.cbFlashRedOnMiss.CheckState = System.Windows.Forms.CheckState.Checked;
      this.cbFlashRedOnMiss.Font = new System.Drawing.Font( "Lucida Sans", 9.75F, System.Drawing.FontStyle.Bold );
      this.cbFlashRedOnMiss.ForeColor = System.Drawing.Color.FromArgb( ( ( int )( ( ( byte )( 211 ) ) ) ), ( ( int )( ( ( byte )( 177 ) ) ) ), ( ( int )( ( ( byte )( 179 ) ) ) ) );
      this.cbFlashRedOnMiss.Location = new System.Drawing.Point( 25, 105 );
      this.cbFlashRedOnMiss.Name = "cbFlashRedOnMiss";
      this.cbFlashRedOnMiss.Size = new System.Drawing.Size( 147, 19 );
      this.cbFlashRedOnMiss.TabIndex = 8;
      this.cbFlashRedOnMiss.Text = "Flash Red On Miss";
      this.cbFlashRedOnMiss.UseVisualStyleBackColor = true;
      // 
      // cbVisualTraining
      // 
      this.cbVisualTraining.AutoSize = true;
      this.cbVisualTraining.Checked = true;
      this.cbVisualTraining.CheckState = System.Windows.Forms.CheckState.Checked;
      this.cbVisualTraining.Font = new System.Drawing.Font( "Lucida Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.cbVisualTraining.ForeColor = System.Drawing.Color.FromArgb( ( ( int )( ( ( byte )( 225 ) ) ) ), ( ( int )( ( ( byte )( 192 ) ) ) ), ( ( int )( ( ( byte )( 130 ) ) ) ) );
      this.cbVisualTraining.Location = new System.Drawing.Point( 18, 19 );
      this.cbVisualTraining.Name = "cbVisualTraining";
      this.cbVisualTraining.Size = new System.Drawing.Size( 125, 19 );
      this.cbVisualTraining.TabIndex = 5;
      this.cbVisualTraining.Text = "Visual Training";
      this.cbVisualTraining.UseVisualStyleBackColor = true;
      // 
      // cbAudioTraining
      // 
      this.cbAudioTraining.AutoSize = true;
      this.cbAudioTraining.Checked = true;
      this.cbAudioTraining.CheckState = System.Windows.Forms.CheckState.Checked;
      this.cbAudioTraining.Font = new System.Drawing.Font( "Lucida Sans", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.cbAudioTraining.ForeColor = System.Drawing.Color.FromArgb( ( ( int )( ( ( byte )( 225 ) ) ) ), ( ( int )( ( ( byte )( 192 ) ) ) ), ( ( int )( ( ( byte )( 130 ) ) ) ) );
      this.cbAudioTraining.Location = new System.Drawing.Point( 18, 136 );
      this.cbAudioTraining.Name = "cbAudioTraining";
      this.cbAudioTraining.Size = new System.Drawing.Size( 124, 19 );
      this.cbAudioTraining.TabIndex = 6;
      this.cbAudioTraining.Text = "Audio Training";
      this.cbAudioTraining.UseVisualStyleBackColor = true;
      // 
      // label1
      // 
      this.label1.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.label1.AutoSize = true;
      this.label1.BackColor = System.Drawing.Color.Transparent;
      this.label1.Location = new System.Drawing.Point( 521, 599 );
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size( 167, 13 );
      this.label1.TabIndex = 1;
      this.label1.Text = "by Shawn Presser and Emily Kolar";
      // 
      // groupBox1
      // 
      this.groupBox1.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( ( System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left ) 
            | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.groupBox1.BackColor = System.Drawing.Color.Transparent;
      this.groupBox1.Controls.Add( this.txtAudioTraining );
      this.groupBox1.Controls.Add( this.txtVisualTraining );
      this.groupBox1.Controls.Add( this.cbVisualTraining );
      this.groupBox1.Controls.Add( this.cbAudioTraining );
      this.groupBox1.Location = new System.Drawing.Point( 12, 138 );
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size( 335, 221 );
      this.groupBox1.TabIndex = 3;
      this.groupBox1.TabStop = false;
      // 
      // txtAudioTraining
      // 
      this.txtAudioTraining.AutoSize = true;
      this.txtAudioTraining.Font = new System.Drawing.Font( "Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.txtAudioTraining.Location = new System.Drawing.Point( 140, 137 );
      this.txtAudioTraining.Name = "txtAudioTraining";
      this.txtAudioTraining.Size = new System.Drawing.Size( 165, 75 );
      this.txtAudioTraining.TabIndex = 1;
      this.txtAudioTraining.Text = "causes Brain Rage \r\nto speak letters to you.\r\nPress J when the spoken\r\nletter is " +
    "the same as\r\n2 letters before.";
      // 
      // txtVisualTraining
      // 
      this.txtVisualTraining.AutoSize = true;
      this.txtVisualTraining.Font = new System.Drawing.Font( "Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.txtVisualTraining.Location = new System.Drawing.Point( 140, 19 );
      this.txtVisualTraining.Name = "txtVisualTraining";
      this.txtVisualTraining.Size = new System.Drawing.Size( 172, 75 );
      this.txtVisualTraining.TabIndex = 1;
      this.txtVisualTraining.Text = "presents you with \r\na sequnce of squares.\r\nPress F when the square\'s\r\nlocation is" +
    " the same as \r\n2 steps back.";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.BackColor = System.Drawing.Color.Transparent;
      this.label3.Font = new System.Drawing.Font( "Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label3.ForeColor = System.Drawing.Color.FromArgb( ( ( int )( ( ( byte )( 255 ) ) ) ), ( ( int )( ( ( byte )( 224 ) ) ) ), ( ( int )( ( ( byte )( 192 ) ) ) ) );
      this.label3.Location = new System.Drawing.Point( 183, 31 );
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size( 116, 23 );
      this.label3.TabIndex = 4;
      this.label3.Text = "Brain Rage";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.BackColor = System.Drawing.Color.Transparent;
      this.label4.Font = new System.Drawing.Font( "Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label4.ForeColor = System.Drawing.Color.White;
      this.label4.Location = new System.Drawing.Point( 294, 38 );
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size( 30, 16 );
      this.label4.TabIndex = 4;
      this.label4.Text = "is a";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.BackColor = System.Drawing.Color.Transparent;
      this.label5.Font = new System.Drawing.Font( "Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label5.ForeColor = System.Drawing.Color.FromArgb( ( ( int )( ( ( byte )( 192 ) ) ) ), ( ( int )( ( ( byte )( 255 ) ) ) ), ( ( int )( ( ( byte )( 192 ) ) ) ) );
      this.label5.Location = new System.Drawing.Point( 321, 38 );
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size( 100, 16 );
      this.label5.TabIndex = 4;
      this.label5.Text = "memory game";
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.BackColor = System.Drawing.Color.Transparent;
      this.label6.Font = new System.Drawing.Font( "Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label6.ForeColor = System.Drawing.Color.White;
      this.label6.Location = new System.Drawing.Point( 419, 38 );
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size( 82, 16 );
      this.label6.TabIndex = 4;
      this.label6.Text = "designed to";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.BackColor = System.Drawing.Color.Transparent;
      this.label7.Font = new System.Drawing.Font( "Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label7.ForeColor = System.Drawing.Color.White;
      this.label7.Location = new System.Drawing.Point( 243, 64 );
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size( 223, 16 );
      this.label7.TabIndex = 4;
      this.label7.Text = "enhance your short term memory.";
      // 
      // groupBox2
      // 
      this.groupBox2.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( ( System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left ) 
            | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.groupBox2.BackColor = System.Drawing.Color.Transparent;
      this.groupBox2.Controls.Add( this.label15 );
      this.groupBox2.Controls.Add( this.label10 );
      this.groupBox2.Controls.Add( this.label9 );
      this.groupBox2.Controls.Add( this.cbMarathonMode );
      this.groupBox2.Controls.Add( this.cbKeepScore );
      this.groupBox2.Controls.Add( this.cbFlashRedOnMiss );
      this.groupBox2.Location = new System.Drawing.Point( 353, 138 );
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size( 335, 221 );
      this.groupBox2.TabIndex = 5;
      this.groupBox2.TabStop = false;
      // 
      // label15
      // 
      this.label15.AutoSize = true;
      this.label15.Font = new System.Drawing.Font( "Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label15.Location = new System.Drawing.Point( 169, 158 );
      this.label15.Name = "label15";
      this.label15.Size = new System.Drawing.Size( 127, 30 );
      this.label15.TabIndex = 1;
      this.label15.Text = "always shows you \r\nyour errors.";
      // 
      // label10
      // 
      this.label10.AutoSize = true;
      this.label10.Font = new System.Drawing.Font( "Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label10.Location = new System.Drawing.Point( 169, 105 );
      this.label10.Name = "label10";
      this.label10.Size = new System.Drawing.Size( 145, 30 );
      this.label10.TabIndex = 1;
      this.label10.Text = "gives you a visual cue\r\nafter a misstep.";
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Font = new System.Drawing.Font( "Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label9.Location = new System.Drawing.Point( 169, 20 );
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size( 140, 45 );
      this.label9.TabIndex = 1;
      this.label9.Text = "causes Brain Rage to\r\ngo into overdrive --\r\nNo breaks for you.";
      // 
      // cbKeepScore
      // 
      this.cbKeepScore.AutoSize = true;
      this.cbKeepScore.Checked = true;
      this.cbKeepScore.CheckState = System.Windows.Forms.CheckState.Checked;
      this.cbKeepScore.Font = new System.Drawing.Font( "Lucida Sans", 9.75F, System.Drawing.FontStyle.Bold );
      this.cbKeepScore.ForeColor = System.Drawing.Color.FromArgb( ( ( int )( ( ( byte )( 211 ) ) ) ), ( ( int )( ( ( byte )( 177 ) ) ) ), ( ( int )( ( ( byte )( 179 ) ) ) ) );
      this.cbKeepScore.Location = new System.Drawing.Point( 25, 158 );
      this.cbKeepScore.Name = "cbKeepScore";
      this.cbKeepScore.Size = new System.Drawing.Size( 103, 19 );
      this.cbKeepScore.TabIndex = 0;
      this.cbKeepScore.Text = "Keep Score";
      this.cbKeepScore.UseVisualStyleBackColor = true;
      // 
      // nBack
      // 
      this.nBack.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.nBack.Location = new System.Drawing.Point( 323, 474 );
      this.nBack.Maximum = new decimal( new int[] {
            19,
            0,
            0,
            0} );
      this.nBack.Minimum = new decimal( new int[] {
            2,
            0,
            0,
            0} );
      this.nBack.Name = "nBack";
      this.nBack.Size = new System.Drawing.Size( 37, 20 );
      this.nBack.TabIndex = 0;
      this.nBack.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
      this.nBack.Value = new decimal( new int[] {
            2,
            0,
            0,
            0} );
      this.nBack.ValueChanged += new System.EventHandler( this.nBack_ValueChanged );
      // 
      // label11
      // 
      this.label11.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.label11.AutoSize = true;
      this.label11.BackColor = System.Drawing.Color.Transparent;
      this.label11.Font = new System.Drawing.Font( "Lucida Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label11.Location = new System.Drawing.Point( 241, 400 );
      this.label11.Name = "label11";
      this.label11.Size = new System.Drawing.Size( 67, 12 );
      this.label11.TabIndex = 4;
      this.label11.Text = "visible for";
      // 
      // btnDoIt
      // 
      this.btnDoIt.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.btnDoIt.BackColor = System.Drawing.Color.Transparent;
      this.btnDoIt.Font = new System.Drawing.Font( "Arial Black", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.btnDoIt.ForeColor = System.Drawing.Color.Black;
      this.btnDoIt.Location = new System.Drawing.Point( 218, 521 );
      this.btnDoIt.Name = "btnDoIt";
      this.btnDoIt.Size = new System.Drawing.Size( 80, 41 );
      this.btnDoIt.TabIndex = 1;
      this.btnDoIt.Text = "play";
      this.btnDoIt.UseVisualStyleBackColor = false;
      this.btnDoIt.Click += new System.EventHandler( this.btnDoIt_Click );
      // 
      // button1
      // 
      this.button1.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.button1.BackColor = System.Drawing.Color.Transparent;
      this.button1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.button1.Font = new System.Drawing.Font( "Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.button1.ForeColor = System.Drawing.Color.Black;
      this.button1.Location = new System.Drawing.Point( 373, 521 );
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size( 80, 41 );
      this.button1.TabIndex = 4;
      this.button1.Text = "quit";
      this.button1.UseVisualStyleBackColor = false;
      // 
      // label2
      // 
      this.label2.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.label2.AutoSize = true;
      this.label2.BackColor = System.Drawing.Color.Transparent;
      this.label2.Location = new System.Drawing.Point( 330, 549 );
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size( 16, 13 );
      this.label2.TabIndex = 7;
      this.label2.Text = "or";
      // 
      // txtDurationTrialActive
      // 
      this.txtDurationTrialActive.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.txtDurationTrialActive.DecimalPlaces = 2;
      this.txtDurationTrialActive.Location = new System.Drawing.Point( 314, 392 );
      this.txtDurationTrialActive.Minimum = new decimal( new int[] {
            1,
            0,
            0,
            131072} );
      this.txtDurationTrialActive.Name = "txtDurationTrialActive";
      this.txtDurationTrialActive.Size = new System.Drawing.Size( 56, 20 );
      this.txtDurationTrialActive.TabIndex = 2;
      this.txtDurationTrialActive.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
      this.txtDurationTrialActive.Value = new decimal( new int[] {
            5,
            0,
            0,
            65536} );
      // 
      // txtDurationTrialHidden
      // 
      this.txtDurationTrialHidden.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.txtDurationTrialHidden.DecimalPlaces = 2;
      this.txtDurationTrialHidden.Location = new System.Drawing.Point( 314, 431 );
      this.txtDurationTrialHidden.Minimum = new decimal( new int[] {
            1,
            0,
            0,
            131072} );
      this.txtDurationTrialHidden.Name = "txtDurationTrialHidden";
      this.txtDurationTrialHidden.Size = new System.Drawing.Size( 56, 20 );
      this.txtDurationTrialHidden.TabIndex = 3;
      this.txtDurationTrialHidden.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
      this.txtDurationTrialHidden.Value = new decimal( new int[] {
            25,
            0,
            0,
            65536} );
      // 
      // label8
      // 
      this.label8.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.label8.AutoSize = true;
      this.label8.BackColor = System.Drawing.Color.Transparent;
      this.label8.Font = new System.Drawing.Font( "Lucida Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label8.Location = new System.Drawing.Point( 376, 400 );
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size( 62, 12 );
      this.label8.TabIndex = 4;
      this.label8.Text = "seconds. ";
      // 
      // label12
      // 
      this.label12.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.label12.AutoSize = true;
      this.label12.BackColor = System.Drawing.Color.Transparent;
      this.label12.Font = new System.Drawing.Font( "Lucida Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label12.Location = new System.Drawing.Point( 238, 439 );
      this.label12.Name = "label12";
      this.label12.Size = new System.Drawing.Size( 68, 12 );
      this.label12.TabIndex = 4;
      this.label12.Text = "hidden for";
      // 
      // label13
      // 
      this.label13.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.label13.AutoSize = true;
      this.label13.BackColor = System.Drawing.Color.Transparent;
      this.label13.Font = new System.Drawing.Font( "Lucida Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label13.Location = new System.Drawing.Point( 376, 439 );
      this.label13.Name = "label13";
      this.label13.Size = new System.Drawing.Size( 62, 12 );
      this.label13.TabIndex = 4;
      this.label13.Text = "seconds. ";
      // 
      // label14
      // 
      this.label14.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.label14.AutoSize = true;
      this.label14.BackColor = System.Drawing.Color.Transparent;
      this.label14.Font = new System.Drawing.Font( "Lucida Sans", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label14.Location = new System.Drawing.Point( 242, 477 );
      this.label14.Name = "label14";
      this.label14.Size = new System.Drawing.Size( 66, 12 );
      this.label14.TabIndex = 4;
      this.label14.Text = "difficulty:";
      // 
      // label16
      // 
      this.label16.AutoSize = true;
      this.label16.BackColor = System.Drawing.Color.Transparent;
      this.label16.Font = new System.Drawing.Font( "Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.label16.ForeColor = System.Drawing.Color.White;
      this.label16.Location = new System.Drawing.Point( 254, 94 );
      this.label16.Name = "label16";
      this.label16.Size = new System.Drawing.Size( 189, 16 );
      this.label16.TabIndex = 4;
      this.label16.Text = "Use the F and J keys to play.";
      // 
      // btnReadMore
      // 
      this.btnReadMore.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right ) ) );
      this.btnReadMore.BackColor = System.Drawing.Color.Transparent;
      this.btnReadMore.Font = new System.Drawing.Font( "Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ( ( byte )( 0 ) ) );
      this.btnReadMore.ForeColor = System.Drawing.Color.Black;
      this.btnReadMore.Location = new System.Drawing.Point( 15, 12 );
      this.btnReadMore.Name = "btnReadMore";
      this.btnReadMore.Size = new System.Drawing.Size( 84, 24 );
      this.btnReadMore.TabIndex = 1;
      this.btnReadMore.Text = "more info";
      this.btnReadMore.UseVisualStyleBackColor = false;
      this.btnReadMore.Click += new System.EventHandler( this.btnReadMore_Click );
      // 
      // label17
      // 
      this.label17.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left ) ) );
      this.label17.AutoSize = true;
      this.label17.Location = new System.Drawing.Point( 12, 600 );
      this.label17.Name = "label17";
      this.label17.Size = new System.Drawing.Size( 93, 13 );
      this.label17.TabIndex = 8;
      this.label17.Text = "Useful?  Consider ";
      // 
      // lblDonate
      // 
      this.lblDonate.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left ) ) );
      this.lblDonate.AutoSize = true;
      this.lblDonate.BackColor = System.Drawing.Color.Transparent;
      this.lblDonate.Location = new System.Drawing.Point( 102, 600 );
      this.lblDonate.Name = "lblDonate";
      this.lblDonate.Size = new System.Drawing.Size( 51, 13 );
      this.lblDonate.TabIndex = 9;
      this.lblDonate.TabStop = true;
      this.lblDonate.Text = "donating.";
      this.lblDonate.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler( this.lblDonate_LinkClicked );
      // 
      // label18
      // 
      this.label18.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left ) ) );
      this.label18.AutoSize = true;
      this.label18.Location = new System.Drawing.Point( 158, 601 );
      this.label18.Name = "label18";
      this.label18.Size = new System.Drawing.Size( 0, 13 );
      this.label18.TabIndex = 10;
      // 
      // Settings
      // 
      this.AcceptButton = this.btnDoIt;
      this.AutoScaleDimensions = new System.Drawing.SizeF( 6F, 13F );
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.FromArgb( ( ( int )( ( ( byte )( 115 ) ) ) ), ( ( int )( ( ( byte )( 120 ) ) ) ), ( ( int )( ( ( byte )( 132 ) ) ) ) );
      this.ClientSize = new System.Drawing.Size( 700, 621 );
      this.ControlBox = false;
      this.Controls.Add( this.lblDonate );
      this.Controls.Add( this.label17 );
      this.Controls.Add( this.txtDurationTrialHidden );
      this.Controls.Add( this.txtDurationTrialActive );
      this.Controls.Add( this.label2 );
      this.Controls.Add( this.button1 );
      this.Controls.Add( this.btnReadMore );
      this.Controls.Add( this.btnDoIt );
      this.Controls.Add( this.label13 );
      this.Controls.Add( this.label14 );
      this.Controls.Add( this.label8 );
      this.Controls.Add( this.label12 );
      this.Controls.Add( this.label11 );
      this.Controls.Add( this.groupBox2 );
      this.Controls.Add( this.nBack );
      this.Controls.Add( this.label16 );
      this.Controls.Add( this.label7 );
      this.Controls.Add( this.label6 );
      this.Controls.Add( this.label4 );
      this.Controls.Add( this.groupBox1 );
      this.Controls.Add( this.label1 );
      this.Controls.Add( this.label5 );
      this.Controls.Add( this.label3 );
      this.Controls.Add( this.label18 );
      this.ForeColor = System.Drawing.Color.White;
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
      this.Name = "Settings";
      this.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler( this.Settings_PreviewKeyDown );
      this.groupBox1.ResumeLayout( false );
      this.groupBox1.PerformLayout();
      this.groupBox2.ResumeLayout( false );
      this.groupBox2.PerformLayout();
      ( ( System.ComponentModel.ISupportInitialize )( this.nBack ) ).EndInit();
      ( ( System.ComponentModel.ISupportInitialize )( this.txtDurationTrialActive ) ).EndInit();
      ( ( System.ComponentModel.ISupportInitialize )( this.txtDurationTrialHidden ) ).EndInit();
      this.ResumeLayout( false );
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.CheckBox cbMarathonMode;
    private System.Windows.Forms.CheckBox cbFlashRedOnMiss;
    private System.Windows.Forms.CheckBox cbVisualTraining;
    private System.Windows.Forms.CheckBox cbAudioTraining;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.Label txtVisualTraining;
    private System.Windows.Forms.Label txtAudioTraining;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Label label10;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.NumericUpDown nBack;
    private System.Windows.Forms.Label label11;
    private System.Windows.Forms.Button btnDoIt;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.NumericUpDown txtDurationTrialActive;
    private System.Windows.Forms.NumericUpDown txtDurationTrialHidden;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.Label label12;
    private System.Windows.Forms.Label label13;
    private System.Windows.Forms.Label label14;
    private System.Windows.Forms.Label label15;
    private System.Windows.Forms.CheckBox cbKeepScore;
    private System.Windows.Forms.Label label16;
    private System.Windows.Forms.Button btnReadMore;
    private System.Windows.Forms.Label label17;
    private System.Windows.Forms.LinkLabel lblDonate;
    private System.Windows.Forms.Label label18;
  }
}